import React from 'react';

const PostDetails = ({ match }) => {
  const { id } = match.params; // Assume que o ID está na URL

  // Busque os detalhes do post com base no ID

  return (
    <div>
      <h2>Post Details</h2>
      <p>Details for post {id}</p>
    </div>
  );
};

export default PostDetails;
