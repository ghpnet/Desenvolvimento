import React from 'react';
import PostList from '../components/PostList';

const Home = () => {
  const posts = [
    { id: 1, title: 'Post 1', content: 'Content for post 1.' },
    { id: 2, title: 'Post 2', content: 'Content for post 2.' },
  ];

  return (
    <div>
      <h1>Blog</h1>
      <PostList posts={posts} />
    </div>
  );
};

export default Home;
