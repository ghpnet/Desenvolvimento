import style from './Dashboard.module.css';

const Dashboard = () => {
    return (
        <div>
            <h2> Simulador Solar </h2>
        </div>
    )
}

export default Dashboard