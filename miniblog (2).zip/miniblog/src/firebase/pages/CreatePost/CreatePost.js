import style from './CreatePost.module.css';

const CreatePost = () => {
    return (
        <div>
            <h2> CreatePost </h2>
        </div>
    )
}

export default CreatePost