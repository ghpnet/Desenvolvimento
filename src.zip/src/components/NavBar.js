export default function Navbar() {
    return (
      <nav>Navigation</nav>
      )
  }