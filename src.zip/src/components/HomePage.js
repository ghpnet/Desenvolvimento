import React from 'react';

const HomePage = () => {
  return <div>Seja bem vindo ao AutoLand, um blog feito em REACTJS</div>;
};

export default HomePage;