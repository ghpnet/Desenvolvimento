import React from 'react';

const PostDetail = () => {
  return (
    <div>
      <h1>Detalhes do Post</h1>
      {/* Renderize os detalhes do post aqui */}
    </div>
  );
};

export default PostDetail;
